# 3. Longest Substring Without Repeating Characters
# https://leetcode.com/problems/longest-substring-without-repeating-characters/

"""
Given a string `s`, find the length of the **longest** **substring** without duplicate characters.

**Example 1:**

```
Input: s = "abcabcbb"
Output: 3
Explanation: The answer is "abc", with the length of 3. Note that "bca" and "cab" are also correct answers.
```

**Example 2:**

```
Input: s = "bbbbb"
Output: 1
Explanation: The answer is "b", with the length of 1.
```

**Example 3:**

```
Input: s = "pwwkew"
Output: 3
Explanation: The answer is "wke", with the length of 3.
Notice that the answer must be a substring, "pwke" is a subsequence and not a substring.
```

**Constraints:**

- `0 <= s.length <= 5 * 104`
- `s` consists of English letters, digits, symbols and spaces.
"""


class Solution:
    def lengthOfLongestSubstring(self, s: str) -> int:
        slow_pointer = 0
        quick_pointer = 1
        if not s:
            return 0
        if len(s) <= 1:
            return len(s)
        while quick_pointer < len(s) :
            if s[slow_pointer] == s[quick_pointer]
        


# ─── 参考解法 ───

# 参考解法：滑动窗口（双指针）
def lengthOfLongestSubstring_sliding_window(self, s: str) -> int:
    """
    滑动窗口解法
    时间复杂度：O(n)，每个字符最多被访问两次
    空间复杂度：O(min(m, n))，m是字符集大小
    """
    char_set = set()  # 记录当前窗口中的字符
    left = 0
    max_length = 0
    
    for right in range(len(s)):
        # 如果当前字符已经在窗口中，移动左指针直到移除重复字符
        while s[right] in char_set:
            char_set.remove(s[left])
            left += 1
        
        # 将当前字符加入窗口
        char_set.add(s[right])
        
        # 更新最大长度
        max_length = max(max_length, right - left + 1)
    
    return max_length

# 优化版本：使用字典记录字符最后出现的位置
def lengthOfLongestSubstring_optimized(self, s: str) -> int:
    """
    优化版本：使用字典记录字符最后出现的位置
    时间复杂度：O(n)
    空间复杂度：O(min(m, n))
    """
    char_index = {}  # 记录字符最后出现的位置
    left = 0
    max_length = 0
    
    for right in range(len(s)):
        # 如果字符出现过且在窗口内，直接移动左指针
        if s[right] in char_index and char_index[s[right]] >= left:
            left = char_index[s[right]] + 1
        
        # 更新字符位置
        char_index[s[right]] = right
        
        # 更新最大长度
        max_length = max(max_length, right - left + 1)
    
    return max_length

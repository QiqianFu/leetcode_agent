# 15. 3Sum
# https://leetcode.com/problems/3sum/

"""
Given an integer array nums, return all the triplets `[nums[i], nums[j], nums[k]]` such that `i != j`, `i != k`, and `j != k`, and `nums[i] + nums[j] + nums[k] == 0`.

Notice that the solution set must not contain duplicate triplets.

**Example 1:**

```
Input: nums = [-1,0,1,2,-1,-4]
Output: [[-1,-1,2],[-1,0,1]]
Explanation: 
nums[0] + nums[1] + nums[2] = (-1) + 0 + 1 = 0.
nums[1] + nums[2] + nums[4] = 0 + 1 + (-1) = 0.
nums[0] + nums[3] + nums[4] = (-1) + 2 + (-1) = 0.
The distinct triplets are [-1,0,1] and [-1,-1,2].
Notice that the order of the output and the order of the triplets does not matter.
```

**Example 2:**

```
Input: nums = [0,1,1]
Output: []
Explanation: The only possible triplet does not sum up to 0.
```

**Example 3:**

```
Input: nums = [0,0,0]
Output: [[0,0,0]]
Explanation: The only possible triplet sums up to 0.
```

**Constraints:**

- `3 <= nums.length <= 3000`
- `-105 <= nums[i] <= 105`
"""


class Solution:
    def threeSum(self, nums: list[int]) -> list[list[int]]:
        


# ─── 参考解法 ───

    def threeSum(self, nums: list[int]) -> list[list[int]]:
        """
        双指针解法（标准解法）
        时间复杂度：O(n²)，空间复杂度：O(1) 或 O(n)（取决于排序）
        """
        nums.sort()  # 先排序，便于去重和使用双指针
        n = len(nums)
        result = []
        
        for i in range(n - 2):  # 固定第一个数
            # 跳过重复的第一个数
            if i > 0 and nums[i] == nums[i - 1]:
                continue
            
            # 如果最小的三个数之和都大于0，后面不可能有解
            if nums[i] + nums[i + 1] + nums[i + 2] > 0:
                break
            
            # 如果当前数加上最大的两个数都小于0，当前数太小，跳过
            if nums[i] + nums[n - 2] + nums[n - 1] < 0:
                continue
            
            # 双指针找两数之和等于 -nums[i]
            left, right = i + 1, n - 1
            target = -nums[i]
            
            while left < right:
                current_sum = nums[left] + nums[right]
                
                if current_sum == target:
                    result.append([nums[i], nums[left], nums[right]])
                    
                    # 跳过重复的left
                    while left < right and nums[left] == nums[left + 1]:
                        left += 1
                    # 跳过重复的right
                    while left < right and nums[right] == nums[right - 1]:
                        right -= 1
                    
                    left += 1
                    right -= 1
                elif current_sum < target:
                    left += 1
                else:
                    right -= 1
        
        return result


# 测试用例
if __name__ == "__main__":
    solution = Solution()
    
    # 测试用例1
    nums1 = [-1, 0, 1, 2, -1, -4]
    print(f"Input: {nums1}")
    print(f"Output: {solution.threeSum(nums1)}")
    print()
    
    # 测试用例2
    nums2 = [0, 1, 1]
    print(f"Input: {nums2}")
    print(f"Output: {solution.threeSum(nums2)}")
    print()
    
    # 测试用例3
    nums3 = [0, 0, 0]
    print(f"Input: {nums3}")
    print(f"Output: {solution.threeSum(nums3)}")

# 5. Longest Palindromic Substring
- 难度: Medium
- 标签: String, Dynamic Programming
- 链接: https://leetcode.com/problems/longest-palindromic-substring/

## 题目要点
给定字符串 s，返回最长回文子串。

## 关键点
- 回文串有"中心对称"的性质，中心扩展法利用这一点
- 注意区分奇数和偶数长度的回文
- `expand_around_center` 退出循环时 left/right 已经超出回文范围，需要 `left+1, right-1`

## 解题思路
使用**中心扩展法**：对每个可能的回文中心（单个字符或两个相邻字符），向两边同时扩展，直到不再满足 `s[left] == s[right]`。
- 奇数长度回文：以某个字符为中心
- 偶数长度回文：以两个相邻字符之间的位置为中心
- 时间复杂度更优，常数因子小

## 踩坑记录
- **自己的第一版**：错误地将字符放入 queue 返回，完全没有回文检测逻辑，显然不可行
- **边界问题**：`expand_around_center` 函数中，循环退出时 left 和 right 已经超出回文范围，需要 `left+1` 和 `right-1` 来得到正确索引

## 关键收获
- 回文串的对称性：中心扩展法充分利用了这一特性，比暴力检测高效
- 两种中心：需要分别处理奇偶长度，这样才能覆盖所有可能的回文
- 空间优化：与 DP O(n^2) 空间相比，中心扩展只需 O(1) 空间

## 复杂度
- **时间**: O(n²)（最坏情况所有字符相同）
- **空间**: O(1)（只需要几个指针）

# 103. Binary Tree Zigzag Level Order Traversal
- 难度: Medium
- 标签: Tree, Breadth-First Search, Binary Tree
- 链接: https://leetcode.com/problems/binary-tree-zigzag-level-order-traversal/

## 解题思路
使用BFS层序遍历，通过队列实现。核心是在普通层序遍历基础上增加方向控制：偶数层从左到右，奇数层从右到左。可以用两种方式实现：1) 正常遍历后对奇数层结果reverse；2) 使用双端队列，根据方向决定从哪端添加节点值。

## 踩坑记录
用户代码中：1) 导入错误（应为`from collections import deque`）；2) 队列使用不当；3) 缺少锯齿形逻辑；4) 每层应该收集节点值而非节点对象；5) 应该在每层循环外创建当前层列表。

## 关键收获
掌握了BFS层序遍历的标准模板：用队列存储节点，记录每层大小，循环处理。学会了锯齿形遍历的两种实现方式：reverse法和双端队列法。理解了如何通过层数奇偶或布尔标志控制遍历方向。

## 复杂度
时间复杂度：O(n)，每个节点访问一次。空间复杂度：O(n)，最坏情况队列存储所有节点。
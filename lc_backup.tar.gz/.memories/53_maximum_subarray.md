# 53. Maximum Subarray
- 难度: Medium
- 标签: Array, Divide and Conquer, Dynamic Programming
- 链接: https://leetcode.com/problems/maximum-subarray/

## 题目要点
给定整数数组，找到和最大的连续子数组，返回其和。

## 关键点
- Kadane 算法的精髓：`max(nums[i], current_sum + nums[i])` — 要么从当前元素重新开始，要么延续之前的子数组
- 自己的第一版用了 numpy 和 O(n^2) 的暴力法，需要掌握 O(n) 的 Kadane 思路

## 相似题
- 70. Climbing Stairs — 同为基础线性 DP
- 300. Longest Increasing Subsequence — 线性 DP，但需要嵌套循环

## 解题思路
自己的第一版用 numpy 初始化 dp 数组，但逻辑错误，混淆了子数组和子集合的定义。参考解法提供三种正确的方法：
- **Kadane 算法**：以当前元素结尾的最大和，决策点是"继续还是重新开始"
- **DP 数组版本**：更明确的 DP 框架，`dp[i] = max(nums[i], dp[i-1] + nums[i])`
- **分治法**：分左右两部分后处理跨中点的最大和

## 踩坑记录
- **一开始的错误**：混淆了"最大子数组"的定义，用暴力 O(n^2) 遍历所有子数组起终点
- **初始化问题**：没有正确理解 dp[i] 的含义，导致状态转移错误

## 关键收获
- Kadane 算法的核心思想：`max(nums[i], current_sum + nums[i])` — 贪心地在"重新开始"和"延续"之间选择
- DP 和贪心的结合：这不仅是 DP，更是一种聪明的贪心策略
- 分治法提供了另一种角度，虽然时间复杂度更高但思路不同

## 复杂度
- **Kadane**: 时间 O(n)，空间 O(1) ✓
- **DP 数组**: 时间 O(n)，空间 O(n)
- **分治**: 时间 O(n log n)，空间 O(log n)

# 322. Coin Change
- 难度: Medium
- 标签: Array, Dynamic Programming, Breadth-First Search
- 链接: https://leetcode.com/problems/coin-change/

## 题目要点
给定不同面额的硬币和一个总金额，求凑成总金额所需的最少硬币数。无法凑成返回 -1。

## 关键点
- 完全背包问题的变体（每种硬币可以用无限次）
- 注意初始化为 inf 而不是 0，否则 min 取不到正确值
- `dp[0] = 0` 是关键 base case（凑成 0 元不需要硬币）

## 相似题
- 70. Climbing Stairs — 类似的"从前面状态转移"思路，但 Climbing Stairs 求方案数而非最小值
- 300. Longest Increasing Subsequence — 一维 DP

## 解题思路
**完全背包 DP**：每种硬币可以无限使用，求凑成指定金额的最少硬币数。
- `dp[i]` = 凑成金额 i 所需的最少硬币数
- 对每个金额 i，遍历所有硬币 coin，如果 `i >= coin`，则 `dp[i] = min(dp[i], dp[i - coin] + 1)`
- 注意初始化：`dp[0] = 0`（凑 0 元不需硬币），其余初始化为 inf（表示暂无法凑）

## 踩坑记录
- **初始化陷阱**：如果直接初始化为 0 而不是 inf，min 操作无法正确过滤不可达状态
- **base case 关键性**：`dp[0] = 0` 是所有转移的基础，缺少它会导致 dp 值全为 0 或 inf

## 关键收获
- 这是经典的完全背包问题变体，与硬币面额无关，只依赖"金额范围"
- DP 状态可以用钱币种类的外循环或内循环遍历（完全背包都行），但要避免重复或漏过
- 返回值判断：`return dp[amount] if dp[amount] != inf else -1`

## 复杂度
- **时间**: O(amount × len(coins))
- **空间**: O(amount)

# 1143. Longest Common Subsequence
- 难度: Medium
- 标签: String, Dynamic Programming
- 链接: https://leetcode.com/problems/longest-common-subsequence/

## 解题思路
典型的二维动态规划问题。定义 `dp[i][j]` 为 `text1[0:i]` 和 `text2[0:j]` 的最长公共子序列长度。状态转移：字符相等时 `dp[i][j] = dp[i-1][j-1] + 1`，不等时 `dp[i][j] = max(dp[i-1][j], dp[i][j-1])`。可以使用滚动数组优化空间复杂度。

## 踩坑记录
用户初始实现中 DP 数组维度设置错误（`len(text2) × len(text1)` 但循环索引对应 `text1[i]` 和 `text2[j]`），且缺少处理空字符串的额外行列。索引访问应为 `text1[i-1]` 和 `text2[j-1]` 而非 `text1[i]` 和 `text2[j]`。

## 关键收获
掌握二维 DP 处理两个序列问题的通用模式，与编辑距离问题思路相似。理解 DP 数组多一行一列处理边界的重要性。学会使用滚动数组将空间复杂度从 O(mn) 优化到 O(min(m,n))。

## 复杂度
- **时间**: O(m×n)，需要填充 m×n 的 DP 表
- **空间**: O(m×n) 基础版，可优化到 O(min(m,n)) 使用滚动数组
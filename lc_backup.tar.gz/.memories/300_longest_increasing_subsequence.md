# 300. Longest Increasing Subsequence
- 难度: Medium
- 标签: Array, Binary Search, Dynamic Programming
- 链接: https://leetcode.com/problems/longest-increasing-subsequence/

## 题目要点
给定整数数组，返回最长严格递增子序列的长度。

## 关键点
- 典型的"以 i 结尾"的 DP 定义方式（区别于"前 i 个元素"）
- O(n^2) 解法容易理解但面试中可能被要求优化到 O(n log n)
- 代码中用了自己的 O(n^2) DP 实现，正确且有完整测试用例

## 相似题
- 53. Maximum Subarray — 同为线性 DP，但 Kadane 可以 O(n)
- 322. Coin Change — 同为一维 DP，但状态定义不同

## 解题思路
**动态规划（O(n²)）**：
- `dp[i]` 表示以 `nums[i]` 结尾的最长递增子序列长度
- 对每个位置 i，遍历所有 j < i，如果 `nums[j] < nums[i]` 则 `dp[i] = max(dp[i], dp[j] + 1)`
- 最终答案是 `max(dp)` 中的最大值

## 踩坑记录
- 实现过程中注意初始化：每个元素自身构成长度为 1 的子序列，即 `dp[i] = 1`
- 嵌套循环中的比较条件 `nums[i] > nums[j]` 确保严格递增

## 关键收获
- **"以 i 结尾"的 DP 定义方式**：这是解决递增子序列问题的关键
- O(n²) 虽然不是最优，但逻辑清晰易于理解，是面试和刷题的好起点
- Follow-up 中的 O(n log n) 贪心+二分需要单独掌握（维护 tails 数组并二分查找）

## 复杂度
- **时间**: O(n²)
- **空间**: O(n) for dp array

## 其他方法
- **贪心+二分搜索**: O(n log n)，更优但较复杂

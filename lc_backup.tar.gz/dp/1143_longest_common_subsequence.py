# 1143. Longest Common Subsequence
# https://leetcode.com/problems/longest-common-subsequence/

"""
Given two strings `text1` and `text2`, return *the length of their longest **common subsequence**.* If there is no **common subsequence**, return `0`.

A **subsequence** of a string is a new string generated from the original string with some characters (can be none) deleted without changing the relative order of the remaining characters.

- For example, `"ace"` is a subsequence of `"abcde"`.

A **common subsequence** of two strings is a subsequence that is common to both strings.

**Example 1:**

```
Input: text1 = "abcde", text2 = "ace" 
Output: 3  
Explanation: The longest common subsequence is "ace" and its length is 3.
```

**Example 2:**

```
Input: text1 = "abc", text2 = "abc"
Output: 3
Explanation: The longest common subsequence is "abc" and its length is 3.
```

**Example 3:**

```
Input: text1 = "abc", text2 = "def"
Output: 0
Explanation: There is no such common subsequence, so the result is 0.
```

**Constraints:**

- `1 <= text1.length, text2.length <= 1000`
- `text1` and `text2` consist of only lowercase English characters.
"""


from pydoc import text


class Solution:
    def longestCommonSubsequence(self, text1: str, text2: str) -> int:
        dp = [[0] * len(text1) for _ in range(len(text2))]
        for i in range(1, len(text1)):
            for j in range(1, len(text2)):
                if text1[i] == text2[j]:
                    dp[i][j] = dp[i-1][j-1] + 1
                else:
                    dp[i][j] = max(dp[i][j-1], dp[i-1][j])

        


# ─── 参考解法 ───

    def longestCommonSubsequence(self, text1: str, text2: str) -> int:
        """
        动态规划解法
        时间复杂度：O(m*n)，空间复杂度：O(m*n)
        """
        m, n = len(text1), len(text2)
        
        # dp[i][j] 表示 text1[0:i] 和 text2[0:j] 的最长公共子序列长度
        # 注意：i 和 j 表示前i个字符和前j个字符，所以数组大小为 (m+1) × (n+1)
        dp = [[0] * (n + 1) for _ in range(m + 1)]
        
        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if text1[i - 1] == text2[j - 1]:
                    # 当前字符相等，LCS长度加1
                    dp[i][j] = dp[i - 1][j - 1] + 1
                else:
                    # 当前字符不相等，取两种选择中的最大值
                    dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
        
        return dp[m][n]


# 空间优化版本（滚动数组）
    def longestCommonSubsequence_optimized(self, text1: str, text2: str) -> int:
        """
        空间优化版本：使用滚动数组
        时间复杂度：O(m*n)，空间复杂度：O(min(m, n))
        """
        # 让text1为较短的字符串，减少空间使用
        if len(text1) > len(text2):
            text1, text2 = text2, text1
        
        m, n = len(text1), len(text2)
        
        # 只需要两行：当前行和上一行
        prev = [0] * (n + 1)
        curr = [0] * (n + 1)
        
        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if text1[i - 1] == text2[j - 1]:
                    curr[j] = prev[j - 1] + 1
                else:
                    curr[j] = max(prev[j], curr[j - 1])
            
            # 滚动数组：当前行变为上一行
            prev, curr = curr, prev
            # 重置当前行（其实不需要，因为会被覆盖）
            # 但为了清晰，可以重置：curr = [0] * (n + 1)
        
        return prev[n]  # 注意：最后prev保存的是最后一行的结果


# 测试用例
if __name__ == "__main__":
    solution = Solution()
    
    # 测试用例1
    text1 = "abcde"
    text2 = "ace"
    print(f"text1 = {text1}, text2 = {text2}")
    print(f"LCS length: {solution.longestCommonSubsequence(text1, text2)}")
    print(f"LCS length (optimized): {solution.longestCommonSubsequence_optimized(text1, text2)}")
    print()
    
    # 测试用例2
    text1 = "abc"
    text2 = "abc"
    print(f"text1 = {text1}, text2 = {text2}")
    print(f"LCS length: {solution.longestCommonSubsequence(text1, text2)}")
    print()
    
    # 测试用例3
    text1 = "abc"
    text2 = "def"
    print(f"text1 = {text1}, text2 = {text2}")
    print(f"LCS length: {solution.longestCommonSubsequence(text1, text2)}")
    print()
    
    # 测试用例4：一个字符串为空
    text1 = ""
    text2 = "abc"
    print(f"text1 = '{text1}', text2 = {text2}")
    print(f"LCS length: {solution.longestCommonSubsequence(text1, text2)}")
    print()
    
    # 测试用例5：较长的字符串
    text1 = "hofubmnylkra"
    text2 = "pqhgxgdofcvmr"
    print(f"text1 = {text1}, text2 = {text2}")
    print(f"LCS length: {solution.longestCommonSubsequence(text1, text2)}")

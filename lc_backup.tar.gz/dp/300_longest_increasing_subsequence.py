# 300. Longest Increasing Subsequence
# https://leetcode.com/problems/longest-increasing-subsequence/

"""
Given an integer array `nums`, return *the length of the longest **strictly increasing*** ***subsequence***.

**Example 1:**

```
Input: nums = [10,9,2,5,3,7,101,18]
Output: 4
Explanation: The longest increasing subsequence is [2,3,7,101], therefore the length is 4.
```

**Example 2:**

```
Input: nums = [0,1,0,3,2,3]
Output: 4
```

**Example 3:**

```
Input: nums = [7,7,7,7,7,7,7]
Output: 1
```

**Constraints:**

- `1 <= nums.length <= 2500`
- `-104 <= nums[i] <= 104`

**Follow up:** Can you come up with an algorithm that runs in `O(n log(n))` time complexity?
"""

from typing import List

class Solution:
    def lengthOfLIS(self, nums: List[int]) -> int:
        if not nums:
            return 0
        total_len = len(nums)
        dp = [1] * total_len

        for i in range(1, total_len):
            max_num = 1
            for j in range(i):

                if nums[i] > nums[j]:
                    max_num = max(max_num, dp[j] +1)
            dp[i] = max_num
        return max(dp)

        




# 测试用例
def test_lengthOfLIS():
    solution = Solution()
    
    # 测试用例1：题目示例1
    nums1 = [10, 9, 2, 5, 3, 7, 101, 18]
    result1 = solution.lengthOfLIS(nums1)
    print(f"Test 1: nums = {nums1}")
    print(f"Expected: 4, Got: {result1}")
    print(f"Pass: {result1 == 4}")
    print()
    
    # 测试用例2：题目示例2
    nums2 = [0, 1, 0, 3, 2, 3]
    result2 = solution.lengthOfLIS(nums2)
    print(f"Test 2: nums = {nums2}")
    print(f"Expected: 4, Got: {result2}")
    print(f"Pass: {result2 == 4}")
    print()
    
    # 测试用例3：题目示例3
    nums3 = [7, 7, 7, 7, 7, 7, 7]
    result3 = solution.lengthOfLIS(nums3)
    print(f"Test 3: nums = {nums3}")
    print(f"Expected: 1, Got: {result3}")
    print(f"Pass: {result3 == 1}")
    print()
    
    # 测试用例4：空数组
    nums4 = []
    result4 = solution.lengthOfLIS(nums4)
    print(f"Test 4: nums = {nums4}")
    print(f"Expected: 0, Got: {result4}")
    print(f"Pass: {result4 == 0}")
    print()
    
    # 测试用例5：单个元素
    nums5 = [5]
    result5 = solution.lengthOfLIS(nums5)
    print(f"Test 5: nums = {nums5}")
    print(f"Expected: 1, Got: {result5}")
    print(f"Pass: {result5 == 1}")
    print()
    
    # 测试用例6：完全递增
    nums6 = [1, 2, 3, 4, 5]
    result6 = solution.lengthOfLIS(nums6)
    print(f"Test 6: nums = {nums6}")
    print(f"Expected: 5, Got: {result6}")
    print(f"Pass: {result6 == 5}")
    print()
    
    # 测试用例7：完全递减
    nums7 = [5, 4, 3, 2, 1]
    result7 = solution.lengthOfLIS(nums7)
    print(f"Test 7: nums = {nums7}")
    print(f"Expected: 1, Got: {result7}")
    print(f"Pass: {result7 == 1}")
    print()
    
    # 测试用例8：复杂情况
    nums8 = [1, 3, 6, 7, 9, 4, 10, 5, 6]
    result8 = solution.lengthOfLIS(nums8)
    print(f"Test 8: nums = {nums8}")
    print(f"Expected: 6, Got: {result8}")
    print(f"Pass: {result8 == 6}")
    print()
    
    # 测试用例9：包含负数
    nums9 = [-2, -1, 0, 1, 2]
    result9 = solution.lengthOfLIS(nums9)
    print(f"Test 9: nums = {nums9}")
    print(f"Expected: 5, Got: {result9}")
    print(f"Pass: {result9 == 5}")
    print()
    
    # 测试用例10：混合正负数
    nums10 = [10, -1, 2, 5, 3, 7, 101, 18]
    result10 = solution.lengthOfLIS(nums10)
    print(f"Test 10: nums = {nums10}")
    print(f"Expected: 5, Got: {result10}")
    print(f"Pass: {result10 == 5}")
    print()
    
    print("All tests completed!")


# 运行测试
if __name__ == "__main__":
    test_lengthOfLIS()

# 103. Binary Tree Zigzag Level Order Traversal
# https://leetcode.com/problems/binary-tree-zigzag-level-order-traversal/

"""
Given the `root` of a binary tree, return *the zigzag level order traversal of its nodes' values*. (i.e., from left to right, then right to left for the next level and alternate between).

**Example 1:**

![](https://assets.leetcode.com/uploads/2021/02/19/tree1.jpg)

```
Input: root = [3,9,20,null,null,15,7]
Output: [[3],[20,9],[15,7]]
```

**Example 2:**

```
Input: root = [1]
Output: [[1]]
```

**Example 3:**

```
Input: root = []
Output: []
```

**Constraints:**

- The number of nodes in the tree is in the range `[0, 2000]`.
- `-100 <= Node.val <= 100`
"""

from typing import List, Optional

# Definition for a binary tree node.
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def zigzagLevelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        import collections
        from collections import queue
        if not root :
            return []
        answer = []
        queue.append(root)
        while len(queue) != 0 :
            for i in range(len(queue)):
                current_list = []
                pop_node = queue.popleft()
                if pop_node.left:
                    current_list.append(pop_node.left)
                if pop_node.right:
                    current_list.append(pop_node.right)
            answer.append(current_list)
            
        


# ─── 参考解法 ───

    # 参考解法：BFS + 方向控制
    def zigzagLevelOrder_bfs(self, root: Optional[TreeNode]) -> List[List[int]]:
        """
        BFS解法：使用队列进行层序遍历，根据层数控制方向
        时间复杂度：O(n)，每个节点访问一次
        空间复杂度：O(n)，最坏情况队列存储所有节点
        """
        from collections import deque
        
        if not root:
            return []
        
        result = []
        queue = deque([root])
        level = 0  # 记录当前层数，0-based
        
        while queue:
            level_size = len(queue)
            current_level = []
            
            for _ in range(level_size):
                node = queue.popleft()
                current_level.append(node.val)
                
                # 添加子节点到队列
                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)
            
            # 根据层数决定方向：偶数层从左到右，奇数层从右到左
            if level % 2 == 1:
                current_level.reverse()
            
            result.append(current_level)
            level += 1
        
        return result
    
    # 优化版本：使用双端队列
    def zigzagLevelOrder_deque(self, root: Optional[TreeNode]) -> List[List[int]]:
        """
        优化版本：使用双端队列，根据方向从不同端操作
        时间复杂度：O(n)
        空间复杂度：O(n)
        """
        from collections import deque
        
        if not root:
            return []
        
        result = []
        queue = deque([root])
        left_to_right = True  # 当前层遍历方向
        
        while queue:
            level_size = len(queue)
            current_level = deque()  # 使用双端队列存储当前层
            
            for _ in range(level_size):
                node = queue.popleft()
                
                # 根据方向决定添加到哪一端
                if left_to_right:
                    current_level.append(node.val)
                else:
                    current_level.appendleft(node.val)
                
                # 添加子节点
                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)
            
            result.append(list(current_level))
            left_to_right = not left_to_right  # 切换方向
        
        return result

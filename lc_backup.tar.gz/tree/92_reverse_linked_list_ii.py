# 92. Reverse Linked List II
# https://leetcode.com/problems/reverse-linked-list-ii/

"""
Given the `head` of a singly linked list and two integers `left` and `right` where `left <= right`, reverse the nodes of the list from position `left` to position `right`, and return *the reversed list*.

**Example 1:**

![](https://assets.leetcode.com/uploads/2021/02/19/rev2ex2.jpg)

```
Input: head = [1,2,3,4,5], left = 2, right = 4
Output: [1,4,3,2,5]
```

**Example 2:**

```
Input: head = [5], left = 1, right = 1
Output: [5]
```

**Constraints:**

- The number of nodes in the list is `n`.
- `1 <= n <= 500`
- `-500 <= Node.val <= 500`
- `1 <= left <= right <= n`

**Follow up:** Could you do it in one pass?
"""

from typing import Optional

# Definition for singly-linked list.
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next
class Solution:
    def reverseBetween(self, head: Optional[ListNode], left: int, right: int) -> Optional[ListNode]:
        if head is not None:
            crr = head.next
        else:
            return head
        left_flag = False
        while head.val != left and left_flag is False:
            next = crr.next
            crr = next
            if crr is None:
                return head
        list_stack = []
        left_flag=True
        list_stack.append(crr)
                
            


# ─── 参考解法 ───

class Solution:
    def reverseBetween(self, head: Optional[ListNode], left: int, right: int) -> Optional[ListNode]:
        # 如果 left == right，不需要反转
        if left == right:
            return head
        
        # 使用 dummy 节点简化边界处理
        dummy = ListNode(0)
        dummy.next = head
        prev = dummy
        
        # 找到 left 前一个节点
        for _ in range(left - 1):
            prev = prev.next
        
        # curr 指向要反转的第一个节点
        curr = prev.next
        
        # 反转 left 到 right 的部分
        # 需要反转的节点数量
        count = right - left + 1
        
        # 经典的三指针反转方法
        for _ in range(count - 1):
            # 保存 curr 的下一个节点
            next_node = curr.next
            # 将 curr 指向 next_node 的下一个节点
            curr.next = next_node.next
            # 将 next_node 插入到 prev 后面
            next_node.next = prev.next
            # 更新 prev 的 next 指针
            prev.next = next_node
        
        return dummy.next

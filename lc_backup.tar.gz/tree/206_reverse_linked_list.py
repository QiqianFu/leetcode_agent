# 206. Reverse Linked List
# https://leetcode.com/problems/reverse-linked-list/

"""
Given the `head` of a singly linked list, reverse the list, and return *the reversed list*.

**Example 1:**

![](https://assets.leetcode.com/uploads/2021/02/19/rev1ex1.jpg)

```
Input: head = [1,2,3,4,5]
Output: [5,4,3,2,1]
```

**Example 2:**

![](https://assets.leetcode.com/uploads/2021/02/19/rev1ex2.jpg)

```
Input: head = [1,2]
Output: [2,1]
```

**Example 3:**

```
Input: head = []
Output: []
```

**Constraints:**

- The number of nodes in the list is the range `[0, 5000]`.
- `-5000 <= Node.val <= 5000`

**Follow up:** A linked list can be reversed either iteratively or recursively. Could you implement both?
"""

from typing import Optional

# Definition for singly-linked list.
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next
class Solution:
    def reverseList(self, head: Optional[ListNode]) -> Optional[ListNode]:
        if head is None:
            return None
        def recursion_find_next(current_node: ListNode) -> ListNode:
            if current_node.next != None:
                first_node = recursion_find_next(current_node.next)
            else: 
                return current_node
            
            next = current_node.next
            next.next = current_node
            current_node.next = None
            return first_node
        first_node = recursion_find_next(head)
        return first_node


head = [ListNode(i) for i in range(1, 6)]
for i in range(len(head) - 1):
    head[i].next = head[i + 1]
current_node = head[0]
while current_node is not None:
    print(current_node.val)
    current_node = current_node.next
answer = Solution().reverseList(head[0])
x= 0 
print("answer")
while answer is not None and x < 10:
    print(answer.val)
    answer = answer.next
    x+=1
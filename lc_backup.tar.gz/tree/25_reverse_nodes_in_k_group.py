# 25. Reverse Nodes in k-Group
# https://leetcode.com/problems/reverse-nodes-in-k-group/

"""
Given the `head` of a linked list, reverse the nodes of the list `k` at a time, and return *the modified list*.

`k` is a positive integer and is less than or equal to the length of the linked list. If the number of nodes is not a multiple of `k` then left-out nodes, in the end, should remain as it is.

You may not alter the values in the list's nodes, only nodes themselves may be changed.

**Example 1:**

![](https://assets.leetcode.com/uploads/2020/10/03/reverse_ex1.jpg)

```
Input: head = [1,2,3,4,5], k = 2
Output: [2,1,4,3,5]
```

**Example 2:**

![](https://assets.leetcode.com/uploads/2020/10/03/reverse_ex2.jpg)

```
Input: head = [1,2,3,4,5], k = 3
Output: [3,2,1,4,5]
```

**Constraints:**

- The number of nodes in the list is `n`.
- `1 <= k <= n <= 5000`
- `0 <= Node.val <= 1000`

**Follow-up:** Can you solve the problem in `O(1)` extra memory space?
"""

from typing import Optional

# Definition for singly-linked list.
class ListNode:
    def __init__(self, val=0, next=None):
        self.val = val
        self.next = next
class Solution:
    def reverseKGroup(self, head: Optional[ListNode], k: int) -> Optional[ListNode]:
        def recursion(cn: int, node: Optional[ListNode]) -> Optional[ListNode]:
            if not node or not node.next:
                return None

            if cn != k - 1:
                lasthead = recursion(cn +1 , node.next)
            else:
                return node
            
            if cn != 0:
                node.next.next = node
                return lasthead
            else:
                node.next.next = node
                node.next = lasthead.next
                return lasthead
        
        if head == None:
            return None
        head = recursion(k, head)
        while recursion(k, head) :
            True
        return head

head = [ListNode(i) for i in range(1, 6)]
for i in range(len(head) - 1):
    head[i].next = head[i + 1]
current_node = head[0]
while current_node is not None:
    print(current_node.val)
    current_node = current_node.next
answer = Solution().reverseKGroup(head[0],3)
x= 0 
print("answer")
while answer is not None and x < 10:
    print(answer.val)
    answer = answer.next
    x+=1
        
            
            

            

        


# ─── 参考解法 ───

# 标准解法 - 递归版本
class Solution:
    def reverseKGroup(self, head: Optional[ListNode], k: int) -> Optional[ListNode]:
        # 1. 检查是否有 k 个节点
        count = 0
        curr = head
        while curr and count < k:
            curr = curr.next
            count += 1
        
        # 2. 如果不足 k 个，直接返回原链表
        if count < k:
            return head
        
        # 3. 反转前 k 个节点
        prev = None
        curr = head
        for _ in range(k):
            next_node = curr.next
            curr.next = prev
            prev = curr
            curr = next_node
        
        # 4. 递归处理剩下的链表
        # head 现在是反转后的尾节点，需要连接到下一组的结果
        head.next = self.reverseKGroup(curr, k)
        
        # 5. prev 是反转后的头节点
        return prev

# 迭代版本 - O(1) 空间复杂度
class Solution2:
    def reverseKGroup(self, head: Optional[ListNode], k: int) -> Optional[ListNode]:
        dummy = ListNode(0)
        dummy.next = head
        prev_group_end = dummy
        
        while True:
            # 检查是否有 k 个节点
            kth = self.get_kth(prev_group_end, k)
            if not kth:
                break
            
            next_group_start = kth.next
            
            # 反转当前组
            prev = kth.next
            curr = prev_group_end.next
            
            while curr != next_group_start:
                next_node = curr.next
                curr.next = prev
                prev = curr
                curr = next_node
            
            # 连接各组
            temp = prev_group_end.next
            prev_group_end.next = kth
            prev_group_end = temp
        
        return dummy.next
    
    def get_kth(self, node, k):
        while node and k > 0:
            node = node.next
            k -= 1
        return node

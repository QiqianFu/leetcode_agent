# 102. Binary Tree Level Order Traversal
# https://leetcode.com/problems/binary-tree-level-order-traversal/

"""
Given the `root` of a binary tree, return *the level order traversal of its nodes' values*. (i.e., from left to right, level by level).

**Example 1:**

![](https://assets.leetcode.com/uploads/2021/02/19/tree1.jpg)

```
Input: root = [3,9,20,null,null,15,7]
Output: [[3],[9,20],[15,7]]
```

**Example 2:**

```
Input: root = [1]
Output: [[1]]
```

**Example 3:**

```
Input: root = []
Output: []
```

**Constraints:**

- The number of nodes in the tree is in the range `[0, 2000]`.
- `-1000 <= Node.val <= 1000`
"""

from typing import List, Optional

# Definition for a binary tree node.
class TreeNode:
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right
class Solution:
    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        queue_list = [root]
        results = []
        while len(queue_list) is not None:
            curr = queue_list.pop()
            


        


# ─── 参考解法 ───

    def levelOrder(self, root: Optional[TreeNode]) -> List[List[int]]:
        # 处理空树的情况
        if not root:
            return []
        
        result = []
        queue = collections.deque([root])  # 使用双端队列
        
        while queue:
            level_size = len(queue)  # 当前层的节点数
            current_level = []  # 存储当前层的节点值
            
            # 处理当前层的所有节点
            for _ in range(level_size):
                node = queue.popleft()  # 从队列左侧取出节点
                current_level.append(node.val)
                
                # 将下一层的节点加入队列
                if node.left:
                    queue.append(node.left)
                if node.right:
                    queue.append(node.right)
            
            result.append(current_level)
        
        return result

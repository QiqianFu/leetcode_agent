# 215. Kth Largest Element in an Array
# 难度: Medium
# 标签: Array, Divide and Conquer, Heap (Priority Queue), Quickselect, Sorting
# https://leetcode.com/problems/kth-largest-element-in-an-array/
#
# --- 题目描述 ---
# Given an integer array `nums` and an integer `k`, return *the* `kth` *largest element in the array*.
# 
# Note that it is the `kth` largest element in the sorted order, not the `kth` distinct element.
# 
# Can you solve it without sorting?
# 
# **Example 1:**
# 
# ```
# Input: nums = [3,2,1,5,6,4], k = 2
# Output: 5
# ```
# 
# **Example 2:**
# 
# ```
# Input: nums = [3,2,3,1,2,4,5,5,6], k = 4
# Output: 4
# ```
# 
# **Constraints:**
# 
# - `1 <= k <= nums.length <= 105`
# - `-104 <= nums[i] <= 104`
#


class Solution:
    def findKthLargest(self, nums: List[int], k: int) -> int:
        


# ─── 参考解法 ───

import heapq

class Solution:
    def findKthLargest(self, nums: List[int], k: int) -> int:
        """
        使用最小堆找到第k大的元素
        思路：维护一个大小为k的最小堆，堆顶就是第k大的元素
        时间复杂度：O(n log k)
        空间复杂度：O(k)
        """
        # 创建最小堆
        heap = []
        
        for num in nums:
            # 将元素加入堆
            heapq.heappush(heap, num)
            
            # 如果堆的大小超过k，弹出最小的元素
            if len(heap) > k:
                heapq.heappop(heap)
        
        # 堆顶就是第k大的元素
        return heap[0]
